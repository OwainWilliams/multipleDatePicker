
  __  __       _ _   _       _        _____        _         _____ _      _               _    _  ___  
 |  \/  |     | | | (_)     | |      |  __ \      | |       |  __ (_)    | |             | |  | |/ _ \ 
 | \  / |_   _| | |_ _ _ __ | | ___  | |  | | __ _| |_ ___  | |__) |  ___| | _____ _ __  | |  | | (_) |
 | |\/| | | | | | __| | '_ \| |/ _ \ | |  | |/ _` | __/ _ \ |  ___/ |/ __| |/ / _ \ '__| | |  | |> _ < 
 | |  | | |_| | | |_| | |_) | |  __/ | |__| | (_| | ||  __/ | |   | | (__|   <  __/ |    | |__| | (_) |
 |_|  |_|\__,_|_|\__|_| .__/|_|\___| |_____/ \__,_|\__\___| |_|   |_|\___|_|\_\___|_|     \____/ \___/ 
                      | |                                                                              
                      |_|                                                                              

Multiple Date Picker for Umbraco 8

This is a ported version of https://github.com/markwemekamp/Umbraco-Multiple-Date-Picker package for Umbraco 7.

This is a Umbraco wrapper for [MultipleDatePicker](https://github.com/arca-computing/MultipleDatePicker)

